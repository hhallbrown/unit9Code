# Labs

* Celebrity lab - https://github.com/WLHS-APCSA-2023/Labs/tree/main/Celebrity
