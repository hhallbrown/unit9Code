# Celebrity Lab

# Materials
* Student Lab in Google Doc form: https://docs.google.com/document/d/1OZoGuA2mYS5ZvWSxhQl6MPGJX5sSpE9YCCn79hTQIXY/edit?usp=sharing
* Java files: https://github.com/WLHS-APCSA-2023/Labs/tree/main/Celebrity/src
